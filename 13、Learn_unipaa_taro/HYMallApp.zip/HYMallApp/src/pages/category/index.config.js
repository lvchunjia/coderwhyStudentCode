export default definePageConfig({
  navigationBarTitleText: '分类'
})
