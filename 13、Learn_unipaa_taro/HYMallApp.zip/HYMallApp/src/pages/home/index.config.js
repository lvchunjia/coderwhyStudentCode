export default definePageConfig({
  navigationBarTitleText: '首页',
  // onReachBottomDistance:400
})
