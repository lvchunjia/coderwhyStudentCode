/* eslint-disable no-undef */
export default definePageConfig({
  navigationBarTitleText: "首页"
});
