export default definePageConfig({
  navigationBarTitleText: '购物车'
})
